from sqlalchemy.orm import declarative_base

Base = declarative_base()

# 👇 Importa todos los modelos aquí para que Alembic los vea
from app.models.user import User
from app.models.role import Role
# Importá otros modelos si los tenés (ej: Product, Permission, etc.)
